module de.hitec.nhplus {
    requires javafx.controls;
    requires javafx.fxml;
    requires org.apache.pdfbox;

    requires org.controlsfx.controls;
    requires java.sql;
    requires org.xerial.sqlitejdbc;
    //requires de.hitec.nhplus;
    //requires de.hitec.nhplus;

    opens de.hitec.nhplus to javafx.fxml;
    opens de.hitec.nhplus.controller to javafx.fxml;
    opens de.hitec.nhplus.model to javafx.base;

    exports de.hitec.nhplus;
    exports de.hitec.nhplus.controller;
    exports de.hitec.nhplus.model;
    exports de.hitec.nhplus.utils;
}